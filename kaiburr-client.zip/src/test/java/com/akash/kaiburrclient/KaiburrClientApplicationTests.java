package com.akash.kaiburrclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaiburrClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
